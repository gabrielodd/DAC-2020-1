
package uff.calculadora;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class CalculadoraServlet extends HttpServlet {
    int i = 1;
    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()){
            Integer n1 = Integer.parseInt(request.getParameter("primeiroNumero"));
            Integer n2 = Integer.parseInt(request.getParameter("segundoNumero"));
            String operacao = request.getParameter("operacao");
            double resultado = 0;
            
            if(operacao.equals("+"))
                resultado = n1 + n2;
            else if(operacao.equals("-"))
                resultado = n1 - n2;
            else if(operacao.equals("/"))
                resultado = (double)n1 / (double)n2;
            else if(operacao.equals("*"))
                resultado = n1 * n2;
        
        String k = String.valueOf(i);
        Cookie ck = new Cookie("visita", k);
        response.addCookie(ck);
        
        int j = Integer.parseInt(ck.getValue());
        if(j==1){
            out.println("Bem vindo <hr>");
        }else{
            out.println("Você visitou " + i + " vezes <hr>");
        }
        i++;
        out.println("O resultado de " + n1 + operacao + n2 + " é " + resultado);
        } 
        
    }
    
    
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    }
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
    

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
